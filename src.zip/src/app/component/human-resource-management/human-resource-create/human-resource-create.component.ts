import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatStep, MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Button } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { PaginatorModule } from 'primeng/paginator';
import { RadioButtonModule } from 'primeng/radiobutton';
import { environment } from '../../../../environments/environment';
import { GridViewComponent } from '../../../base/shared/grid-view/grid-view.component';
import { MTreeComponent } from '../../../base/shared/m-tree/m-tree.component';
import { CommonUtils } from '../../../base/utils/CommonUtils';
import { InputCommon } from '../../../common/directives/input.directive';
import { ShowClearOnFocusDirective } from '../../../common/directives/showClearOnFocusDirective';
import {
  GROUP_ENDPOINT,
  HR_ENDPOINT,
  ORGANIZATION_ENDPOINT,
} from '../../../common/enum/EApiUrl';
import { REGEX_PATTERN } from '../../../common/enum/RegexPattern';
import {
  convertLstAreaByOrder,
  fomatAddress,
  generatePassword,
} from '../../../common/helpers/Ultils';
import { FetchApiService } from '../../../common/service/api/fetch-api.service';
import { AuthenticationService } from '../../../common/service/auth/authentication.service';
import { DialogCommonService } from '../../../common/service/dialog-common/dialog-common.service';
import { ToastService } from '../../../common/service/toast/toast.service';
import { GridViewModel } from '../../../model/GridViewModel';
import { IErrorRespone } from '../../../model/ma/funtion-group.model';
import {
  DialogRoleComponent,
  DialogRoleModel,
} from '../../role-management/dialog-role/dialog-role.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import moment from 'moment';

@Component({
  selector: 'app-human-resource-create',
  standalone: true,
  imports: [
    Button,
    InputCommon,
    InputTextModule,
    InputTextareaModule,
    MatButton,
    MatStep,
    MatStepper,
    PaginatorModule,
    ReactiveFormsModule,
    GridViewComponent,
    CalendarModule,
    CommonModule,
    ShowClearOnFocusDirective,
    MTreeComponent,
    MatCheckboxModule,
    RadioButtonModule,
    MatTooltipModule
  ],
  templateUrl: './human-resource-create.component.html',
  styleUrl: './human-resource-create.component.scss',
})
export class HumanResourceCreateComponent implements OnInit {
  assetPath = environment.assetPath;
  @ViewChild('gridViewRef') gridViewComponent!: GridViewComponent;
  @ViewChild('mTreeComponent') mTreeComponent!: MTreeComponent;
  id!: number;
  formInfo!: FormGroup;
  totalItem: number = 0;
  currentStep: number = 0;
  isSearch: boolean = false;
  maxDate: Date = new Date();
  lstDataRole: any = [];
  roleId: string = '';
  isSuccess: number = 0;
  isHaveEmail: boolean = false;
  userInfo!: any;
  roles: any = [];
  pointSales: any = [];
  pointSales2: any = [];
  organization: any = [];
  organizationSort: any = [];
  organizationIdActive: number | null = null;
  typeUpdate!: number;
  searchOrganization: string = '';
  masterIdSelected: number | null = null;
  pointSalesSelected: Set<any> = new Set();
  organizationSelected: any[] = [];
  totalPointSalesSelected: number = 0;
  countSelectedPoint: number = 0;
  activeOrganization: string = '';
  isShowMechantList: boolean = false;
  searchPoint: boolean = false;
  isSelectGroup: boolean = false;
  isShowSearchPointSales: boolean = false;
  checkGroupHasPoinSales: boolean = false;


  lstGroupIdMerchant: any[] = [];
  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private router: Router,
    private messageService: MessageService,
    private toast: ToastService,
    private api: FetchApiService,
    private auth: AuthenticationService,
    private routeActive: ActivatedRoute,
    private dialogCommon: DialogCommonService
  ) {
    this.routeActive.queryParams.subscribe((params) => { });
  }

  ngOnInit(): void {
    this.buildForm();
    this.userInfo = this.auth.getUserInfo();
    if (this.userInfo?.isConfig == 0) {
      this.getLstMerchant(true);
    } else {
      this.typeUpdate = 2;
      if (this.userInfo.orgType != 2) this.doGetGroup();
      if (this.userInfo.orgType == 2) this.getLstMerchant(true);
    }
  }
  ngOnChanges(): void {
    this.checkShowTextSearchPoinsales();
  }
  columns: Array<GridViewModel> = [
    {
      name: 'id',
      label: 'ID',
      options: {
        width: '5%',
        customCss: (obj: any) => {
          return ['text-left'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
        customBodyRender: (value: any) => {
          return value ? `#${value}` : '';
        },
      },
    },
    {
      name: 'name',
      label: 'TÊN VAI TRÒ',
      options: {
        width: '35%',
        customCss: (obj: any) => {
          return ['text-left','mw-140'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
    {
      name: 'description',
      label: 'MÔ TẢ',
      options: {
        width: '60%',
        customCss: (obj: any) => {
          return ['text-left','mw-160'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
  ];
  columnsMerchant: Array<GridViewModel> = [
    {
      name: 'merchantId',
      label: 'ID',
      options: {
        width: '5%',
        customCss: () => {
          return ['text-left'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
        customBodyRender: (value: any) => {
          return value ? `#${value}` : '';
        },
      },
    },
    {
      name: 'merchantBizName',
      label: 'TÊN ĐIỂM KINH DOANH',
      options: {
        width: '45%',
        customCss: () => {
          return ['text-left','mw-120'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
    {
      name: 'formatAddress',
      label: 'ĐỊA CHỈ',
      options: {
        width: '50%',
        customCss: () => {
          return ['text-left','mw-180'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
  ];
  buildForm() {
    this.formInfo = this.fb.group({
      fullName: [
        '',
        [
          Validators.required,
          Validators.maxLength(50),
          Validators.pattern(REGEX_PATTERN.FULL_NAME),
        ],
      ],
      emailChange: [
        '',
        [
          Validators.maxLength(254),
          Validators.pattern(REGEX_PATTERN.EMAIL),
          this.validateEmailPrefix,
        ],
      ],
      phoneNumber: ['', [Validators.pattern(REGEX_PATTERN.PHONE)]],
      dateOfBirth: [''],
      userName: [
        '',
        [
          Validators.required,
          Validators.maxLength(100),
          Validators.pattern(REGEX_PATTERN.USER_NAME),
        ],
      ],
      userPass: ['', [Validators.required]],
    });
  }
  checkShowTextSearchPoinsales() {
    console.log(this.activeOrganization);
    var group = this.organization.filter((gr: any) => gr.id == this.organizationIdActive);
    if (group && group.chidren.length == 0 && this.pointSales.length > 0) {
      this.isShowMechantList = true;
    }
    this.isShowMechantList = false;
  }
  openCreateGroups() {
    window.open(this.assetPath + '/organization', '_blank', 'noopener,noreferrer');
  }
  doGetGroup() {
    this.api.post(ORGANIZATION_ENDPOINT.GET_LIST_GROUPS).subscribe(
      (res: any) => {
        if (res.data && res.data.length > 0) {
          this.organization = res.data;
          this.organizationSort = convertLstAreaByOrder(
            res.data,
            res.data[0].parentId
          );
        }
      },
      (error: any) => {
        var errData: IErrorRespone = error.error;
        switch (errData.soaErrorCode) {
          case 'GROUP_ERROR_007':
            this.toast.showError('Nhóm không tồn tại hoặc đã bị vô hiệu hóa!');
            break;
          default:
            this.toast.showError(
              'Có lỗi trong quá trình xử lý. Vui lòng thử lại sau!'
            );
            break;
        }
      }
    );
  }
  // convertLstAreaByOrder(list: any[], parentId: number | null): any[] {
  //   let result = list.filter((item) => item.parentId === parentId);
  //   result.forEach((item) => {
  //     let children = this.convertLstAreaByOrder(list, item.id);
  //     item.children = children;
  //   });

  //   return result;
  // }

  doActiveArea(group: any) {
    this.organizationIdActive = null;
    this.activeOrganization = '';
    this.countSelectedPoint = 0;
    this.organizationIdActive = group.id;
    this.activeOrganization = group.groupName;
    this.isShowSearchPointSales = false;
    if (group.children.length == 0) {
      this.getLstMerchant();
      setTimeout(() => {
        if (this.pointSales.length > 0) {
          this.isShowSearchPointSales = true;
        }
      }, 300)
    } else {
      this.pointSales = [];
    }
  }

  selectMearchant(event: any) {
    if (event.checked) {
      this.masterIdSelected = this.userInfo?.merchantId;
      if (this.mTreeComponent) {
        this.mTreeComponent.checkAllItems(true);
      }
      this.organizationSelected = [];
    } else {
      this.masterIdSelected = null;
      this.mTreeComponent.checkAllItems(false);
      this.organizationSelected = [];
    }
  }

  getLstMerchant(firstSearch: boolean = false) {
    this.isSearch = true;
    let dataReq = {
      groupIdList: this.activeOrganization ? [this.organizationIdActive] : [],
      status: '',
      methodId: [],
      mappingKey: '',
    };
    let param = {
      size: 1000,
      keySearch: this.searchOrganization ? this.searchOrganization : null,
    };
    let buildParams = CommonUtils.buildParams(param);
    this.api
      .post(GROUP_ENDPOINT.GET_POINT_SALE, dataReq, buildParams)
      .subscribe(
        (res: any) => {
          if (res['data']['subInfo'] && res['data']['subInfo'].length > 0) {
            this.pointSales = res['data']['subInfo'];
            this.pointSales = res['data']['subInfo'].map((item: any) => ({
              ...item,
              formatAddress: fomatAddress([
                item.address,
                item.communeName,
                item.districtName,
                item.provinceName,
              ]),
            }));
            if (firstSearch) {
              if (this.pointSales.length == 1) {
                this.pointSalesSelected.add(this.pointSales[0].merchantId);
                this.typeUpdate = 1;
                this.getLstRole();
              } else {
                this.typeUpdate = 0;
              }
            }
            else {
              this.isShowMechantList = true;
            }
            if (this.pointSalesSelected.size > 0) {
              this.pointSales.forEach((item: any) => {
                item.checked = this.pointSalesSelected.has(item.merchantId);
              });
              this.countSelectedPoint = this.pointSales.filter(
                (x: any) => x.checked
              ).length;
            }
          } else {
            this.pointSales = [];
          }
        },
        (error: any) => {
          this.toast.showError('Lấy danh sách điểm kinh doanh xảy ra lỗi.');
        }
      );
  }
  doCheckDisableAnotherlevel(level: number) {
    this.organization.forEach((item: any) => {
      if (item.level != level) {
        item.disabled = true;
      }
    });
    this.organizationSort = convertLstAreaByOrder(
      this.organization,
      this.organization[0].parentId
    );
  }
  doCheckUnDisableAnotherlevel(level: number) {
    if (this.organizationSelected.length == 0) {
      this.organization.forEach((item: any) => {
        if (item.level != level) {
          item.disabled = false;
        }
      });
      this.organizationSort = convertLstAreaByOrder(
        this.organization,
        this.organization[0].parentId
      );
    }
  }
  doCheckGroup(event: any) {
    this.roleId = '';
    this.isSelectGroup = false;
    this.isShowSearchPointSales = false;
    if (event.checked) {
      this.organizationSelected.push(event.id);
      this.isSelectGroup = true;
      this.pointSalesSelected = new Set();
      if (event.children.length == 0) {
        this.isSelectGroup = true;
        this.getLstMerchant();
        setTimeout(() => {
          if (this.pointSales.length > 0) {
            this.isShowSearchPointSales = true;
          }
          this.countSelectedPoint = this.pointSales.length;
        }, 200)
        setTimeout(() => {
          if (this.gridViewComponent) {
            this.gridViewComponent.doCheckAllPointSales();
          }
        }, 500)
      }
      else {
        this.pointSales = [];
      }
      this.doCheckDisableAnotherlevel(event.level);
    } else {
      this.organizationSelected = this.organizationSelected.filter(
        (item: string) => item !== event.id
      );
      this.isSelectGroup = false;
      if (event.children.length == 0) {
        this.countSelectedPoint = 0;
        this.pointSales = [];
      }
      this.doCheckUnDisableAnotherlevel(event.level);
    }
  }
  setUpMerchantIds(event: any) {
    if (this.gridViewComponent) {
      this.gridViewComponent.doUnCheckAllPointSales();
    }

    if (event && Array.isArray(event)) {
      let dataChange = event.map((item) => item.merchantId);
      let groupId = event.map((item) => item.groupId);
      if (event[0]?.checked) {
        this.addListToSet(dataChange);
        groupId.forEach((id) => this.lstGroupIdMerchant?.push(id));
      } else {
        this.removeListFromSet(dataChange);
        groupId.forEach((id) => {
          const index = this.lstGroupIdMerchant?.indexOf(id);
          if (index !== undefined && index !== -1) {
            this.lstGroupIdMerchant?.splice(index, 1);
          }
        });
      }
    } else {
      if (event.checked) {
        this.pointSalesSelected.add(event?.merchantId);
        this.lstGroupIdMerchant?.push(event?.groupId);
      } else {
        this.pointSalesSelected.delete(event?.merchantId);
        const index = this.lstGroupIdMerchant?.indexOf(event?.groupId);
        if (index !== undefined && index !== -1) {
          this.lstGroupIdMerchant?.splice(index, 1);
        }
      }
    }
    this.roleId = '';
    if (this.mTreeComponent) {
      this.mTreeComponent.checkAllItems(false);
    }

    this.totalPointSalesSelected = this.pointSalesSelected.size;
    this.markChecked(this.organizationSort, this.lstGroupIdMerchant);

  }
  radioSetUpMerchantIds(event: any) {
    this.pointSalesSelected.add(event.merchantId);
    this.totalPointSalesSelected = this.pointSalesSelected.size;
  }
  seletedPointSales(event: any) {
    if (this.gridViewComponent) {
      this.countSelectedPoint = event;
    } else {
      this.countSelectedPoint = 0;
    }
  }
  onRadioChange(event: any) {
    this.masterIdSelected = event;
    if (this.masterIdSelected) {
      this.pointSalesSelected = new Set();
    }
  }
  // markChecked(parentList: any[], childList: any[]) {
  //   const childIds = new Set(childList.map((item) => item.id));
  //   parentList.forEach((item) => {
  //     item.checked = childIds.has(item.id);
  //   });
  //   return parentList;
  // }

  addListToSet(listToAdd: number[]): void {
    listToAdd.forEach((item) => this.pointSalesSelected.add(item));
  }

  removeListFromSet(listToRemove: number[]): void {
    listToRemove.forEach((item) => this.pointSalesSelected.delete(item));
  }
  onStepChange(event: StepperSelectionEvent) {
    this.currentStep = event.selectedIndex;
  }
  doNextStep(number: number = 0) {
    if (number == 1) {
      this.getLstRole();
    }
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }
  doPreStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
    } else {
      this.onCancel();
    }
  }
  setRoleId(event: any) {
    this.roleId = event['id'];
  }
  clearValue(nameInput: string) {
    this.formInfo.get(nameInput)?.setValue('');
  }
  createPassword() {
    const newPassword = generatePassword();
    this.formInfo.get('userPass')?.setValue(newPassword);
  }
  copyPassword() {
    const password = this.formInfo.get('userPass')?.value;
    if (!password) return;
    navigator.clipboard
      .writeText(password)
      .then(() => {
        this.toast.showSuccess('Đã sao chép');
      })
      .catch(() => {
        this.toast.showError('Lỗi, Không thể sao chép!');
      });
  }

  returnSelected(item: any) {
    this.roleId = item['id'];
  }

  getLstRole() {
    let orgTypeCreate = 2;
    if (this.masterIdSelected) {
      orgTypeCreate = 0;
    }
    if (this.organizationSelected.length > 0) {
      orgTypeCreate = 1;
    }
    this.api
      .get(
        HR_ENDPOINT.GET_ROLE_BY_USER_LOGIN + '?newUserOrgType=' + orgTypeCreate
      )
      .subscribe((res) => {
        this.roles = res['data']['roleList'];
      });
  }

  trimValue(controlName: string) {
    const control = this.formInfo.get(controlName);
    if (control) {
      control.setValue(control.value.trim());
    }
  }
  allowPattern(event: KeyboardEvent) {
    const target = event.target as HTMLInputElement;
    let pattern: RegExp = /.*/;
    let maxLength = 254;

    switch (target?.id) {
      case "email":
        pattern = /^[a-zA-Z0-9._%+\-@]$/;
        maxLength = 254;
        break;
      case "userName":
        pattern = /^[a-zA-Z0-9._@'\-]$/;
        maxLength = 50;
        break;
    }
    if (
      !pattern.test(event.key) ||
      event.key === " " ||
      target.value.length >= maxLength
    ) {
      event.preventDefault();
    }
  }
  createHr() {
    let params = this.formInfo.getRawValue();
    params['dateOfBirth'] = moment(params['dateOfBirth']).format('DD/MM/YYYY') ;
    params['roleId'] = this.roleId;
    params['organizationInfo'] = {
      masterId:
        this.pointSalesSelected.size > 0 || this.organizationSelected.length > 0
          ? ''
          : this.masterIdSelected,
      merchantIds: Array.from(this.pointSalesSelected),
      groupIds:
        this.pointSalesSelected.size > 0 ? [] : this.organizationSelected,
    };
    this.api.post(HR_ENDPOINT.CREATE_HR, params).subscribe(
      (res) => {
        if (res['data']['emailChange']) {
          this.isHaveEmail = true;
        }
        this.isSuccess = 1;
        this.doNextStep();
      },
      (error) => {
        const errorData = error?.error || {};
        switch (errorData.soaErrorCode) {
          case 'USER_CREATION_ERROR_003':
            this.formInfo.get('userName')!.setErrors({ userNameExist: true });
            break;
          case 'USER_CREATION_ERROR_004':
            this.formInfo.get('emailChange')!.setErrors({ emailExist: true });
            break;
          case 'USER_CREATION_ERROR_005':
            this.formInfo
              .get('phoneNumber')!
              .setErrors({ phoneNumberExist: true });
            break;
          default:
            this.toast.showError(errorData?.soaErrorDesc);
            this.isSuccess = 0;
            this.doNextStep();
            break;
        }
      }
    );
  }

  onCancel() {
    let dataConfirm: DialogRoleModel = new DialogRoleModel();
    dataConfirm.title = `Hủy thêm mới nhân sự`;
    dataConfirm.message =
      'Các thông tin sẽ không được lưu lại. Bạn có chắc chắn muốn huỷ thêm mới nhân sự không?';
    dataConfirm.icon = 'icon-error';
    dataConfirm.iconColor = 'error';
    dataConfirm.buttonRightColor = 'error';

    const dialogRef = this.dialog.open(DialogRoleComponent, {
      width: '600px',
      data: dataConfirm,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.router.navigate(['/hr']);
      }
    });
  }

  getSelectedItemForRadio(): any {
    return this.roles.find((p: any) => p.id === this.roleId);
  }

  validateEmailPrefix(control: AbstractControl): ValidationErrors | null {
    const email = control.value;
    if (!email) return null;

    const parts = email.split('@');
    if (parts.length < 2) return null; // chưa có @ thì không kiểm tra

    const prefix = parts[0];

    // Kiểm tra ký tự hợp lệ và độ dài
    const isValidLength = prefix.length >= 4 && prefix.length <= 64;

    if (!isValidLength) {
      return {
        localPartLength: true,
      };
    }

    return null;
  }

  markChecked(parentList: any[], childList: number[]): any[] {
    if (parentList?.length && childList?.length) {
      this.flatParentGroup(parentList, childList);

      // const childIds = new Set(childList);
      // parentList.forEach((item) => {
      //   if (this.pointSalesSelected.size > 0 && childIds.has(item.id)) {
      //     item.checked = 'partial';
      //   } else {
      //     item.checked = childIds.has(item.id);
      //   }
      // });
    } else if (parentList?.length) {
      parentList.forEach((item) => {
        item.checked = false;
      });
    }
    return parentList;
  }

  flatParentGroup(parentList: any[], childList: number[]) {
    parentList.forEach((item) => {
      const childIds = new Set(childList);
      if (item?.children?.length > 0) {
        this.flatParentGroup(item?.children, childList);
      }
      if (this.pointSalesSelected.size > 0 && childIds.has(item.id)) {
        item.checked = 'partial';
      } else {
        item.checked = childIds.has(item.id);
      }
    });
  }
}
