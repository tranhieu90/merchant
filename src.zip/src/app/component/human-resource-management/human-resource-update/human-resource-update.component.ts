import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatStep, MatStepper } from '@angular/material/stepper';
import { Router } from '@angular/router';
import { Button } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { PaginatorModule } from 'primeng/paginator';
import { GridViewComponent } from '../../../base/shared/grid-view/grid-view.component';
import { InputCommon } from '../../../common/directives/input.directive';
import { ToastService } from '../../../common/service/toast/toast.service';
import { GridViewModel } from '../../../model/GridViewModel';
import {
  DialogRoleComponent,
  DialogRoleModel,
} from '../../role-management/dialog-role/dialog-role.component';
import { CommonUtils } from '../../../base/utils/CommonUtils';
import {
  GROUP_ENDPOINT,
  HR_ENDPOINT,
  ORGANIZATION_ENDPOINT,
} from '../../../common/enum/EApiUrl';
import { FetchApiService } from '../../../common/service/api/fetch-api.service';
import { AuthenticationService } from '../../../common/service/auth/authentication.service';
import { AreaModel } from '../../../model/AreaModel';
import { CommonModule } from '@angular/common';
import { TreeModule } from 'primeng/tree';
import { MTreeComponent } from '../../../base/shared/m-tree/m-tree.component';
import { catchError, map, Observable, of } from 'rxjs';
import { isArray } from 'lodash';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { IPersonelUpdate } from '../../../model/ma/personel.model';
import { environment } from '../../../../environments/environment';
import {
  convertLstAreaByOrder,
  fomatAddress,
  setDisableOrNotForItemsNotAtLevel,
} from '../../../common/helpers/Ultils';
import { AreaViewComponent } from '../../organization-management/area-view/area-view.component';
import { TreeViewComponent } from '../../../base/shared/tree-view/tree-view.component';
import { MTreeCheckboxComponent } from '../../../base/shared/m-tree-checkbox/m-tree-checkbox.component';
@Component({
  selector: 'app-human-resource-update',
  standalone: true,
  imports: [
    Button,
    InputCommon,
    InputTextModule,
    InputTextareaModule,
    MatButton,
    MatStep,
    MatStepper,
    PaginatorModule,
    ReactiveFormsModule,
    GridViewComponent,
    CalendarModule,
    AreaViewComponent,
    CommonModule,
    TreeModule,
    MatCheckboxModule,
    RadioButtonModule,
    MTreeComponent,
    TreeViewComponent,
    MTreeCheckboxComponent,
  ],
  templateUrl: './human-resource-update.component.html',
  styleUrl: './human-resource-update.component.scss',
})
export class HumanResourceUpdateComponent implements OnInit {
  @ViewChild('mTreeComponent') mTreeComponent!: MTreeComponent;
  assetPath = environment.assetPath;
  id!: number;
  totalItem: number = 0;
  currentStep: number = 0;
  isSearch: boolean = false;
  maxDate: Date = new Date();
  userInfo!: any;
  typeUpdate!: number;
  lstAreas: AreaModel[] = [];

  listgroupIdInMerchant?: number[] = [];
  lstAreaByOrder: AreaModel[] = [];
  areaActive: AreaModel = new AreaModel();
  subMerchantList: any[] = [];
  treeNodes?: any;
  keyWord!: string;
  groupList: any = [];
  groupListClone: any = [];
  roleId!: number;
  userId!: number;
  activeItemId: number | null = null;
  merchantIds: Set<number> = new Set();
  merchantIdsClone: Set<number> = new Set();
  totalMerchant: number = 0;
  pointSales: any = [];
  selectedMerchantDefault: any[] = [];
  selectedGroupDefault: any[] = [];
  roleIdDefault: number = 0;
  isUpdateRole: boolean = false;
  isSuccess: number = 0;
  isHaveEmail: boolean = false;
  masterId?: number;
  orgTypeUser!: number;
  isCheckboxMerchant: boolean = false;
  isShowPointSales: boolean = false;
  isShowGroup: boolean = false;
  isShowMerchant: boolean = false;
  orgTypeLogin!: number;
  newRoleId!: string;
  newOrganization!: any;
  isChooseOrganization: boolean = false;
  roleIdSeletecd!: any;
  personDataDetail!: any;
  searchGroup!: string;
  searchPointSales!: string;
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private toast: ToastService,
    private api: FetchApiService,
    private auth: AuthenticationService
  ) {
    const state = this.router.getCurrentNavigation()?.extras.state;
    const personData = state?.['dataInput'];
    console.log('personData', personData);
    if (personData) {
      this.personDataDetail = personData;
      this.userId = personData.userId;
      this.orgTypeUser = personData.orgType;
      if (this.orgTypeUser==2 && personData?.selectedMerchant) {
        if (
          personData?.selectedMerchant &&
          isArray(personData?.selectedMerchant)
        ) {
          this.selectedMerchantDefault = personData?.selectedMerchant;
        } else {
          this.selectedMerchantDefault.push(personData?.selectedMerchant);
        }
      }
      this.roleIdDefault = personData.roleId;
      this.masterId = personData.masterId;
      const groupList = personData?.groupList;
      if (this.orgTypeUser==1 && groupList) {
        const maxLevel = Math.min(...groupList.map((x: any) => x.level));
        this.selectedGroupDefault = groupList;
        this.newOrganization = this.selectedGroupDefault.map(
          (group: any) => group.id
        );
      }
    }
  }
  //isConfig=0 orgType=0 pointsales==0   typeUpdate=0 => bỏ qua  vào vai trò gán vào merchant
  //isConfig=0 orgType=0 pointsales > 0  typeUpdate=1 => hiển thị opt 1 3 : 3 là radio button.
  //isConfig=0 orgType=2 typeUpdate=2     => vào luôn vai trò =>
  //isConfig=1 orgType=0 typeUpdate=3=> hiển thị 3 opt
  //isConfig=1 orgType=1 typeUpdate=4 => hiện thị 2 3 3là hiển thị checkbox
  //isConfig=1 orgType=2 pointsales > 0 typeUpdate= 5
  //isConfig=1 orgType=2 pointsales == 1 typeUpdate=6
  ngOnInit(): void {
    this.isSearch = true;
    this.userInfo = this.auth.getUserInfo();
    let lstPoinSales: any[] = [];
    this.getLstMerchantWithCheckedObs(true)?.subscribe(
      (dataPointSales: any[]) => {
        lstPoinSales.push(...dataPointSales);
        if (this.selectedMerchantDefault.length > 0)
          lstPoinSales.forEach((item) => {
            if (
              this.selectedMerchantDefault.some(
                (x: any) => x.merchantId == item.merchantId
              )
            ) {
              item.checked = true;
            }
          });
        const orgTypeLogin = this.userInfo?.orgType;
        this.orgTypeLogin = orgTypeLogin;
        if (this.userInfo?.isConfig == 0) {
          if (lstPoinSales.length == 0) {
            if (orgTypeLogin == 0) {
              this.typeUpdate = 0;
              this.isChooseOrganization = false;
            }
          }
          if (lstPoinSales.length > 0) {
            if (orgTypeLogin == 0) {
              this.typeUpdate = 1;
              this.isChooseOrganization = true;
            }
            if (orgTypeLogin == 2) {
              this.isChooseOrganization = false;
              this.typeUpdate = 2;
            }
          }
        } else {
          if (orgTypeLogin == 0) {
            this.isChooseOrganization = true;
            this.doGetGroupListLogin().subscribe((data) => {
              this.lstAreas = data;
              if (this.selectedGroupDefault.length > 0) {
                const _level = this.selectedGroupDefault[0].level;
                data.forEach((item) => {
                  if (
                    this.selectedGroupDefault.some((x: any) => x.id == item.id)
                  ) {
                    item.checked = true;
                  }
                  if (item.level != _level) {
                    item.disabled = true;
                  }
                });
              }
              this.lstAreaByOrder = convertLstAreaByOrder(
                this.lstAreas,
                this.lstAreas[0]?.parentId
              );
            });
            this.typeUpdate = 3;
          }
          if (orgTypeLogin == 1) {
            this.isChooseOrganization = true;
            this.typeUpdate = 4;
            this.doGetGroupListLogin().subscribe((data) => {
              this.lstAreas = data;
              if (this.selectedGroupDefault.length > 0) {
                const _level = this.selectedGroupDefault[0].level;
                data.forEach((item) => {
                  if (
                    this.selectedGroupDefault.some((x: any) => x.id == item.id)
                  ) {
                    item.checked = true;
                  }
                  if (item.level != _level) {
                    item.disabled = true;
                  }
                });
              }
              this.lstAreaByOrder = convertLstAreaByOrder(
                this.lstAreas,
                this.lstAreas[0]?.parentId
              );
            });
          }
          if (orgTypeLogin == 2) {
            if (lstPoinSales.length == 1) {
              this.isChooseOrganization = false;
              this.typeUpdate = 2;
            } else {
              this.isChooseOrganization = true;
              this.typeUpdate = 5;
            }
          }
        }
        if (this.typeUpdate == 0 || this.typeUpdate == 2) {
          this.getLstRole();
        }
      }
    );
  }
  columns: Array<GridViewModel> = [
    {
      name: 'id',
      label: 'ID',
      options: {
        width: '10%',
        customCss: (obj: any) => {
          return ['text-left'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
        customBodyRender: (value: any) => {
          return value ? `# ${value}` : '';
        },
      },
    },
    {
      name: 'name',
      label: 'TÊN VAI TRÒ',
      options: {
        width: '25%',
        customCss: (obj: any) => {
          return ['text-left', 'mw-140'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
    {
      name: 'description',
      label: 'MÔ TẢ',
      options: {
        width: '60%',
        customCss: (obj: any) => {
          return ['text-left', 'mw-160'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
  ];
  columnsMerchant: Array<GridViewModel> = [
    {
      name: 'merchantId',
      label: 'ID',
      options: {
        customCss: (obj: any) => {
          return ['text-left'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
    {
      name: 'merchantBizName',
      label: 'TÊN ĐIỂM KINH DOANH',
      options: {
        customCss: (obj: any) => {
          return ['text-left', 'mw-120'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
    {
      name: 'formatAddress',
      label: 'ĐỊA CHỈ',
      options: {
        customCss: (obj: any) => {
          return ['text-left', 'mw-180'];
        },
        customCssHeader: () => {
          return ['text-left'];
        },
      },
    },
  ];
  dataRoles: any = [];
  dataBusiness: any = [];

  doSearch(pageInfo?: any) {
    this.totalItem = 10;
  }

  onStepChange(event: StepperSelectionEvent) {
    this.currentStep = event.selectedIndex;
  }

  doPreStep() {
    this.currentStep--;
  }

  doNextStep(number: number = 0) {
    if (number == 1) {
      this.getLstRole();
    }
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }

  doNextStepSubmit() {
    const param: IPersonelUpdate = {
      userId: this.userId,
      roleId: this.roleIdDefault,
    };
    let isChangeInfo = false;

    if (
      this.personDataDetail.orgType != this.orgTypeUser ||
      (this.roleIdSeletecd && this.roleIdSeletecd.id == this.roleIdDefault)
    ) {
      isChangeInfo = true;
    }
    if (this.orgTypeUser == 0) {
      if (this.personDataDetail.orgType == 0) {
        param.oraganizationInfo = {
          masterId: this.auth.getUserInfo().merchantId,
        };
      }
      if (this.personDataDetail.orgType == 1) {
        let lstGr!: any;
        if (
          this.selectedGroupDefault &&
          Array.isArray(this.selectedGroupDefault)
        ) {
          const lstGr = this.selectedGroupDefault.map((g: any) => g.id);
        }
        param.oraganizationInfo = {
          masterId: this.auth.getUserInfo().merchantId,
          groupIds: lstGr,
        };
      }
      if (this.personDataDetail.orgType == 2) {
        let lstPointSales!: any;
        if (this.personDataDetail?.selectedMerchant) {
          lstPointSales = this.personDataDetail?.selectedMerchant.map(
            (item: any) => item.merchantId
          );
        }
        param.oraganizationInfo = {
          masterId: this.auth.getUserInfo().merchantId,
          merchantIds: lstPointSales,
        };
      }

      if (
        this.selectedMerchantDefault &&
        Array.isArray(this.selectedMerchantDefault)
      ) {
        lstPointSales = this.selectedMerchantDefault.map(
          (item: any) => item.merchantId
        );
      }
    }

    if (this.orgTypeUser == 1) {
      const selectedGroupIds = this.selectedGroupDefault.map((g: any) => g.id);
      if (this.personDataDetail.orgType == 1) {
        const groupIdsInsert = selectedGroupIds.filter(
          (id: any) => !this.newOrganization.includes(id)
        );
        const groupIdsDelete = this.newOrganization.filter(
          (id: any) => !selectedGroupIds.includes(id)
        );
        if (groupIdsInsert.length > 0) {
          param.oraganizationInfo = {
            groupIds: groupIdsInsert,
          };
        }
        if (groupIdsDelete.length > 0) {
          param.oraganizationDelete = {
            groupIds: groupIdsDelete,
          };
        }
      } else if (this.personDataDetail.orgType == 0) {
        param.oraganizationInfo = {
          groupIds: selectedGroupIds,
        };
        param.oraganizationDelete = {
          masterId: this.auth.getUserInfo().merchantId,
        };
      } else {
        let lstPointSales!: any;
        if (this.personDataDetail?.selectedMerchant) {
          lstPointSales = this.personDataDetail?.selectedMerchant.map(
            (item: any) => +item.merchantId
          );
        }
        param.oraganizationInfo = {
          groupIds: selectedGroupIds,
        };
        param.oraganizationDelete = {
          merchantIds: lstPointSales,
        };
      }
    }
    if (this.orgTypeUser == 2) {
      const selectedPointSales = this.selectedMerchantDefault.map(
        (g: any) => g.merchantId
      );
      if (this.personDataDetail.orgType == 2) {
        var lstPointSales = this.personDataDetail?.selectedMerchant.map(
          (item: any) => item.merchantId
        );
        const pointsInsert = selectedPointSales.filter(
          (id: number) => !lstPointSales.includes(id)
        );
        const pointsDelete = lstPointSales.filter(
          (id: number) => !selectedPointSales.includes(id)
        );
        if (pointsInsert.length > 0) {
          param.oraganizationInfo = {
            merchantIds: pointsInsert,
          };
        }
        if (pointsDelete.length > 0) {
          param.oraganizationDelete = {
            merchantIds: pointsDelete,
          };
        }
      } else if (this.personDataDetail.orgType == 0) {
        param.oraganizationInfo = {
          merchantIds: selectedPointSales,
        };
        param.oraganizationDelete = {
          masterId: this.auth.getUserInfo().merchantId,
        };
      } else {
        param.oraganizationInfo = {
          merchantIds: selectedPointSales,
        };
        param.oraganizationDelete = {
          groupIds: this.newOrganization,
        };
      }
    }
    this.api.post(HR_ENDPOINT.UPDATE_HR, param).subscribe(
      (res) => {
        this.isSuccess = res.data.status;
      },
      (err) => {
        if (err) {
          const { error } = err;
          this.toast.showError(error.soaErrorDesc);
        } else this.toast.showError('Đã xảy ra lỗi. Vui lòng thử lại sau.');
      }
    );
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }
  onCancel() {
    let dataConfirm: DialogRoleModel = new DialogRoleModel();
    dataConfirm.title = `Hủy cập nhật nhân sự`;
    dataConfirm.message =
      'Các thông tin sẽ không được lưu lại. Bạn có chắc chắn muốn huỷ cập nhật nhân sự không?';
    dataConfirm.icon = 'icon-error';
    dataConfirm.iconColor = 'error';
    dataConfirm.buttonRightColor = 'error';

    const dialogRef = this.dialog.open(DialogRoleComponent, {
      width: '600px',
      data: dataConfirm,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.router.navigate(['hr/hr-detail'], {
          queryParams: { userId: this.userId },
        });
      }
    });
  }
  doGetGroupListLogin(): Observable<any[]> {
    return this.api.post(ORGANIZATION_ENDPOINT.GET_LIST_GROUPS).pipe(
      map((res: any) => {
        if (res.data && res.data.length > 0) {
          return res.data;
        }
        return [];
      }),
      catchError((error) => {
        this.toast.showError('Lấy danh sách nhóm xảy ra lỗi');
        return of([]);
      })
    );
  }
  doGroup(group: any) {
    if (group.checked) {
      if (this.selectedGroupDefault.length == 0) {
        setDisableOrNotForItemsNotAtLevel(this.lstAreas, group.level, true);
      }
      this.selectedGroupDefault.push(group);
    } else {
      const index = this.selectedGroupDefault.findIndex(
        (x: any) => x.id === group.id
      );
      if (index !== -1) {
        this.selectedGroupDefault.splice(index, 1);
      }
      if (group.children && Array.isArray(group.children)) {
        group.children.forEach((child: any) => {
          const childIndex = this.selectedGroupDefault.findIndex(
            (x: any) => x.id === child.id
          );
          if (childIndex !== -1) {
            this.selectedGroupDefault.splice(childIndex, 1);
          }
        });
      }
      if (this.selectedGroupDefault.length == 0) {
        setDisableOrNotForItemsNotAtLevel(this.lstAreas, group.level, false);
      }
      this.lstAreaByOrder = convertLstAreaByOrder(
        this.lstAreas,
        this.lstAreas[0]?.parentId
      );
    }
  }

  getLstMerchant() {
    return this.getLstMerchantWithCheckedObs(true)?.subscribe();
  }

  getLstMerchantWithCheckedObs(isFirstLoad?: boolean): Observable<any[]> {
    this.isSearch = true;
    let dataReq = {
      groupIdList: [] as number[],
      status: '',
      methodId: [],
      mappingKey: this.searchPointSales,
    };
    let param = {
      page: 1,
      size: 1000,
      keySearch: this.keyWord ? this.keyWord : null,
    };
    let buildParams = CommonUtils.buildParams(param);
    return this.api
      .post(GROUP_ENDPOINT.GET_POINT_SALE, dataReq, buildParams)
      .pipe(
        map((res: any) => {
          if (res['data']['subInfo'] && res['data']['subInfo'].length > 0) {
            let dataGroup = res['data']['subInfo'].map((item: any) => ({
              ...item,
              formatAddress: fomatAddress([
                item.address,
                item.communeName,
                item.districtName,
                item.provinceName,
              ]),
            }));
            this.subMerchantList = dataGroup;
            return dataGroup;
          } else {
            this.subMerchantList = [];
            return [];
          }
        }),
        catchError((err) => {
          this.toast.showError('Lấy danh sách điểm kinh doanh xảy ra lỗi.');
          return of([]);
        })
      );
  }
  setUpMerchantIds(event: any) {
    if (event && Array.isArray(event)) {
      if (event[0]?.checked) {
        this.selectedMerchantDefault.push(...event);
      } else {
        if (Array.isArray(this.selectedMerchantDefault)) {
          event.forEach((item: any) => {
            const idx = this.selectedMerchantDefault.findIndex(
              (m: any) => m.merchantId === item.merchantId
            );
            if (idx !== -1) {
              this.selectedMerchantDefault.splice(idx, 1);
            }
          });
        }
      }
    } else {
      if (event.checked) {
        this.selectedMerchantDefault.push(event);
      } else {
        const index = this.listgroupIdInMerchant?.indexOf(event?.groupId);
        if (index !== undefined && index !== -1) {
          this.listgroupIdInMerchant?.splice(index, 1);
        }
      }
    }
  }
  onRadioChange(event: any) {
    switch (event) {
      case 0:
        this.orgTypeUser = 0;
        this.searchGroup = '';
        this.searchPointSales = '';
        break;
      case 1:
        this.orgTypeUser = 1;
        this.searchGroup = '';
        this.searchPointSales = '';
        break;
      case 2:
        this.orgTypeUser = 2;
        this.searchGroup = '';
        this.searchPointSales = '';
        this.getLstMerchantWithCheckedObs(true)?.subscribe(
      (dataPointSales: any[]) => {
        if (this.selectedMerchantDefault.length > 0)
         { dataPointSales.forEach((item) => {
            if (
              this.selectedMerchantDefault.some(
                (x: any) => x.merchantId == item.merchantId
              )
            ) {
              item.checked = true;
            }
          })}})
        break;
    }
  }
  radioMerchant(event: any) {
    this.selectedMerchantDefault = [];
    this.selectedMerchantDefault.push(event);
  }
  getSelectedItemForRadio(): any {
    if (this.selectedMerchantDefault.length > 0)
      return this.subMerchantList.find(
        (p: any) => p.merchantId === +this.selectedMerchantDefault[0].merchantId
      );
  }

  setRoleId(event: any) {
    this.roleIdDefault = event['id'];
    this.roleIdSeletecd = this.dataRoles.find(
      (p: any) => p.id === this.roleIdDefault
    );
    console.log(this.roleIdSeletecd)
  }

  getLstRole() {
    this.api
      .get(
        HR_ENDPOINT.GET_ROLE_BY_USER_LOGIN +
          '?newUserOrgType=' +
          this.orgTypeUser
      )
      .subscribe((res) => {
        this.dataRoles = res['data']['roleList'];
        this.roleIdSeletecd = this.dataRoles.find(
          (p: any) => p.id === this.roleIdDefault
        );
      });
  }
  getSelectedItemRoleForRadio(): any {
    return this.dataRoles.find((p: any) => p.id === this.roleIdDefault);
  }
  truncateString(str: string): string {
    if (str && str.length > 100) {
      return str.substring(0, 100) + '...';
    }
    return str;
  }
  openCreateGroups() {
    window.open(
      this.assetPath + '/organization',
      '_blank',
      'noopener,noreferrer'
    );
  }
  doActiveAreaCheckbox(group: any) {
    this.lstAreaByOrder.forEach((i: any) => {
      if (i !== group) i.expanded = false;
    });
  }
  checkChangeOrganization(){
    if (
      this.personDataDetail.orgType !== this.orgTypeUser
    ) {
      return true;
    }
    if (this.orgTypeUser === 2) {
      const currentIds = (this.selectedMerchantDefault || []).map((m: any) => m.merchantId).sort();
      const originalIds = (this.personDataDetail.selectedMerchant || []).map((m: any) => m.merchantId).sort();
      if (currentIds.length !== originalIds.length) {
        return true;
      }
      for (let i = 0; i < currentIds.length; i++) {
        if (currentIds[i] !== originalIds[i]) {
          return true;
        }
      }
    }
    if (this.orgTypeUser === 1) {
      const currentGroupIds = (this.selectedGroupDefault || []).map((g: any) => g.id).sort();
      const originalGroupIds = (this.personDataDetail.groupList || []).map((g: any) => g.id).sort();
      if (currentGroupIds.length !== originalGroupIds.length) {
        return true;
      }
      for (let i = 0; i < currentGroupIds.length; i++) {
        if (currentGroupIds[i] !== originalGroupIds[i]) {
          return true;
        }
      }
    }
    return false;
  }
  checkHasOrganzation(){
    if (this.orgTypeUser === 2) {
      return Array.isArray(this.selectedMerchantDefault) && this.selectedMerchantDefault.length > 0;
    }
    if (this.orgTypeUser === 1) {
      return Array.isArray(this.selectedGroupDefault) && this.selectedGroupDefault.length > 0;
    }
    if (this.orgTypeUser === 0) {
      return true;
    }
    return false;
  }
  checkRoleUpdate(){
    if(this.checkChangeOrganization())
    {
      if (!this.dataRoles.some((role: any) => role.id === this.roleIdSeletecd?.id)) {
        return true;
      }
    }
    return false;
  }
}
