import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-management',
  standalone: true,
  imports: [],
  templateUrl: './transaction-management.component.html',
  styleUrl: './transaction-management.component.scss'
})
export class TransactionManagementComponent {

}
