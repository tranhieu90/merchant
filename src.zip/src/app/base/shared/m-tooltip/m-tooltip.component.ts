import { Component } from '@angular/core';

@Component({
  selector: 'app-m-tooltip',
  standalone: true,
  imports: [],
  templateUrl: './m-tooltip.component.html',
  styleUrl: './m-tooltip.component.scss'
})
export class MTooltipComponent {

}
