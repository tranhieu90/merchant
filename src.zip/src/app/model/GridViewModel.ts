export class GridViewModel {
    name!: string;
    label!: string;
    options!: any;
}